from flask import Flask, render_template, request, redirect, url_for
from flask_sqlalchemy import SQLAlchemy

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///novo_banco.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

db = SQLAlchemy(app)

# Definição das classes de modelo
class Usuario(db.Model):
    __tablename__ = 'usuario'
    id = db.Column(db.Integer, primary_key=True)
    nome = db.Column(db.String(255), nullable=False)
    email = db.Column(db.String(255), unique=True, nullable=False)

class Tarefa(db.Model):
    __tablename__ = 'tarefa'
    id = db.Column(db.Integer, primary_key=True)
    id_usuario = db.Column(db.Integer, db.ForeignKey('usuario.id'), nullable=False)
    descricao = db.Column(db.Text, nullable=False)
    nome_setor = db.Column(db.String(255), nullable=False)
    prioridade = db.Column(db.String(50), nullable=False)
    data_cadastro = db.Column(db.DateTime, default=db.func.now())
    status = db.Column(db.String(50), nullable=False, default='a fazer')

# Criação das tabelas no banco de dados
with app.app_context():
    print("Iniciando a criação do banco de dados e tabelas...")
    db.create_all()
    print("Banco de dados e tabelas criados com sucesso.")

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        name = request.form['name']
        email = request.form['email']
        print(f"Tentando cadastrar usuário: {name} - {email}")
        
        # Verificação para evitar duplicação de email
        existing_user = Usuario.query.filter_by(email=email).first()
        if existing_user:
            print("Erro: Email já cadastrado.")
            return render_template('register.html', error_message="Email já cadastrado!")
        
        new_user = Usuario(nome=name, email=email)
        db.session.add(new_user)
        print("Usuário adicionado à sessão. Tentando salvar no banco de dados...")
        db.session.commit()
        print("Usuário salvo com sucesso no banco de dados.")
        
        return render_template('register.html', success_message="Usuário cadastrado com sucesso!")
    
    return render_template('register.html')

@app.route('/users')
def list_users():
    print("Listando todos os usuários.")
    users = Usuario.query.all()
    return render_template('users.html', users=users)

@app.route('/task_register', methods=['GET', 'POST'])
def task_register():
    if request.method == 'POST':
        descricao = request.form['descricao']
        nome_setor = request.form['nome_setor']
        prioridade = request.form['prioridade']
        status = request.form['status']
        id_usuario = request.form['id_usuario']
        
        print(f"Tentando cadastrar tarefa: {descricao}, {nome_setor}, {prioridade}, {status}, {id_usuario}")
        
        new_task = Tarefa(
            descricao=descricao,
            nome_setor=nome_setor,
            prioridade=prioridade,
            status=status,
            id_usuario=id_usuario
        )
        db.session.add(new_task)
        print("Tarefa adicionada à sessão. Tentando salvar no banco de dados...")
        db.session.commit()
        print("Tarefa salva com sucesso no banco de dados.")
        
        return render_template('task_register.html', success_message="Tarefa cadastrada com sucesso!")
    
    users = Usuario.query.all()
    return render_template('task_register.html', users=users)

@app.route('/tasks')
def manage_tasks():
    print("Listando todas as tarefas.")
    tasks = Tarefa.query.all()
    users = {user.id: user.nome for user in Usuario.query.all()}
    return render_template('manage_tasks.html', tasks=tasks, users=users)

@app.route('/update_task/<int:task_id>', methods=['GET', 'POST'])
def update_task(task_id):
    print(f"Tentando atualizar a tarefa com ID: {task_id}")
    task = db.session.get(Tarefa, task_id)
    users = Usuario.query.all()

    if request.method == 'POST':
        task.descricao = request.form['descricao']
        task.nome_setor = request.form['nome_setor']
        task.prioridade = request.form['prioridade']
        task.status = request.form['status']
        task.id_usuario = request.form['id_usuario']
        
        db.session.commit()
        print("Tarefa atualizada com sucesso.")
        return redirect(url_for('manage_tasks'))

    return render_template('update_task.html', task=task, users=users)

@app.route('/delete_task/<int:task_id>', methods=['POST'])
def delete_task(task_id):
    print(f"Tentando excluir a tarefa com ID: {task_id}")
    task = db.session.get(Tarefa, task_id)
    db.session.delete(task)
    db.session.commit()
    print("Tarefa excluída com sucesso.")
    return redirect(url_for('manage_tasks'))

if __name__ == '__main__':
    app.run(debug=True)
