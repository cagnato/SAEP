Projeto de Gerenciamento de Tarefas
Este é um projeto de gerenciamento de tarefas desenvolvido em Flask. Ele permite cadastrar, visualizar, atualizar e deletar usuários e tarefas.

Pré-requisitos
Antes de começar, certifique-se de que possui os seguintes softwares instalados:

Python 3.7 ou superior
Pip (geralmente já incluso com Python)
Virtualenv (opcional, mas recomendado para manter as dependências isoladas)
Configuração do Ambiente

1. Clone o Repositório
Primeiro, faça o clone deste repositório em sua máquina:

bash
Copiar código
git clone <URL_DO_REPOSITORIO>
cd nome_do_projeto

2. Crie um Ambiente Virtual
Para garantir que as dependências do projeto não afetem outros projetos, crie um ambiente virtual:

bash
Copiar código
python -m venv venv

3. Ative o Ambiente Virtual

bash
Copiar código
source venv/bin/activate

4. Instale as Dependências
Instale as bibliotecas necessárias, como Flask e SQLAlchemy, com o comando:

bash
Copiar código
pip install -r requirements.txt
Se o arquivo requirements.txt não estiver presente, instale as dependências manualmente:

bash
Copiar código
pip install Flask Flask-SQLAlchemy

5. Configuração do Banco de Dados
O projeto utiliza SQLite. Ao rodar o projeto pela primeira vez, o arquivo novo_banco.db será criado automaticamente na pasta instance (ou na raiz do projeto, dependendo da configuração). Certifique-se de que a configuração do caminho do banco de dados em app.py está correta:

python
Copiar código
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///instance/novo_banco.db'

6. Executando o Projeto
Para iniciar o servidor Flask, use o comando:

bash
Copiar código
python app.py
Acesse o projeto no navegador em http://127.0.0.1:5000.

//Estrutura do Projeto//

app.py: Arquivo principal do servidor, contém as rotas e configurações.
instance/novo_banco.db: Banco de dados SQLite (criado automaticamente na primeira execução).
templates/: Contém os arquivos HTML usados para renderizar as páginas.
static/: Arquivos estáticos como CSS para estilização.

//Testando o Projeto//

Acesse a página inicial para verificar a conexão com o servidor.
Tente cadastrar um novo usuário na página de cadastro.
Navegue para a lista de usuários e verifique se o novo cadastro foi salvo corretamente.

//Observações//
Caso enfrente problemas:

Verifique o terminal para mensagens de erro.
Certifique-se de que todas as dependências foram instaladas corretamente.
Certifique-se de que o banco de dados novo_banco.db foi criado.

//Manutenção//
Atualização de dependências: Atualize as dependências conforme necessário.
Backup do banco de dados: Faça o backup de novo_banco.db para preservar dados importantes.